import pandas as pd

def __init__(self):
    pass

def fit(self,X,y=None):
    return self

def transform(self,X,y=None):
    X = pd.DataFrame(X).copy()
    X['words'] = X['medical_abstracts'].apply(word_tokenize)
    return X